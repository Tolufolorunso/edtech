"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { useAuthStore } from "@/store/auth-store"
import styles from "./live-class.module.css"

interface Participant {
  id: string
  name: string
  role: string
  isMuted: boolean
  isVideoOn: boolean
  isScreenSharing: boolean
  isHandRaised: boolean
}

interface Message {
  id: string
  sender: string
  text: string
  timestamp: Date
  isPrivate: boolean
  recipient?: string
}

export default function LiveClassPage({ params }: { params: { classid: string } }) {
  const router = useRouter()
  const { user } = useAuthStore()
  const [loading, setLoading] = useState(true)
  const [classInfo, setClassInfo] = useState<any>(null)
  const [participants, setParticipants] = useState<Participant[]>([])
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [isMuted, setIsMuted] = useState(false)
  const [isVideoOn, setIsVideoOn] = useState(true)
  const [isScreenSharing, setIsScreenSharing] = useState(false)
  const [isHandRaised, setIsHandRaised] = useState(false)
  const [isChatOpen, setIsChatOpen] = useState(false)
  const [isParticipantsOpen, setIsParticipantsOpen] = useState(false)
  const [selectedParticipant, setSelectedParticipant] = useState<string | null>(null)
  const [isPrivateMessage, setIsPrivateMessage] = useState(false)
  const chatContainerRef = useRef<HTMLDivElement>(null)
  const [isAuthenticated, setIsAuthenticated] = useState(!!user)

  useEffect(() => {
    setIsAuthenticated(!!user)
  }, [user])

  // Check if user is authenticated
  if (!isAuthenticated) {
    return (
      <div className={styles.container}>
        <div className={styles.unauthorized}>
          <h1>Unauthorized Access</h1>
          <p>Please log in to join this live class.</p>
          <button onClick={() => router.push("/login")} className={styles.loginButton}>
            Log In
          </button>
        </div>
      </div>
    )
  }

  // Fetch class data
  useEffect(() => {
    // In a real app, this would fetch the class data from an API
    const fetchClassData = async () => {
      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Mock class data
        const mockClassInfo = {
          id: params.classid,
          title: "React Native Fundamentals Q&A",
          instructor: "John Doe",
          bootcamp: "React Native Masterclass",
          week: 1,
          description: "Live session to answer questions about React Native fundamentals.",
          startTime: new Date(),
          duration: "2 hours",
        }

        // Mock participants
        const mockParticipants: Participant[] = [
          {
            id: "1",
            name: "John Doe",
            role: "instructor",
            isMuted: false,
            isVideoOn: true,
            isScreenSharing: false,
            isHandRaised: false,
          },
          {
            id: "2",
            name: "Jane Smith",
            role: "student",
            isMuted: true,
            isVideoOn: true,
            isScreenSharing: false,
            isHandRaised: false,
          },
          {
            id: "3",
            name: "Bob Johnson",
            role: "student",
            isMuted: true,
            isVideoOn: false,
            isScreenSharing: false,
            isHandRaised: true,
          },
          {
            id: "4",
            name: "Alice Williams",
            role: "student",
            isMuted: true,
            isVideoOn: true,
            isScreenSharing: false,
            isHandRaised: false,
          },
          {
            id: "5",
            name: "Charlie Brown",
            role: "student",
            isMuted: true,
            isVideoOn: true,
            isScreenSharing: false,
            isHandRaised: false,
          },
        ]

        // Mock messages
        const mockMessages: Message[] = [
          {
            id: "1",
            sender: "John Doe",
            text: "Welcome to the React Native Fundamentals Q&A session!",
            timestamp: new Date(Date.now() - 1000 * 60 * 5),
            isPrivate: false,
          },
          {
            id: "2",
            sender: "Jane Smith",
            text: "I have a question about setting up the development environment.",
            timestamp: new Date(Date.now() - 1000 * 60 * 4),
            isPrivate: false,
          },
          {
            id: "3",
            sender: "John Doe",
            text: "Sure, Jane. What specific issue are you having?",
            timestamp: new Date(Date.now() - 1000 * 60 * 3),
            isPrivate: false,
          },
          {
            id: "4",
            sender: "Bob Johnson",
            text: "I'm also having trouble with the setup. Can you go over the iOS configuration again?",
            timestamp: new Date(Date.now() - 1000 * 60 * 2),
            isPrivate: false,
          },
          {
            id: "5",
            sender: "John Doe",
            text: "Let me share my screen and walk through the setup process again.",
            timestamp: new Date(Date.now() - 1000 * 60 * 1),
            isPrivate: false,
          },
        ]

        setClassInfo(mockClassInfo)
        setParticipants(mockParticipants)
        setMessages(mockMessages)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching class data:", error)
        setLoading(false)
      }
    }

    fetchClassData()
  }, [params.classid])

  // Scroll to bottom of chat when new messages are added
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight
    }
  }, [messages])

  // Handle sending a message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()

    if (newMessage.trim() === "") return

    const newMsg: Message = {
      id: `msg-${Date.now()}`,
      sender: user.name,
      text: newMessage,
      timestamp: new Date(),
      isPrivate: isPrivateMessage,
      recipient: isPrivateMessage ? selectedParticipant || undefined : undefined,
    }

    setMessages([...messages, newMsg])
    setNewMessage("")
    setIsPrivateMessage(false)
    setSelectedParticipant(null)
  }

  // Handle toggling mute
  const handleToggleMute = () => {
    setIsMuted(!isMuted)
  }

  // Handle toggling video
  const handleToggleVideo = () => {
    setIsVideoOn(!isVideoOn)
  }

  // Handle toggling screen sharing
  const handleToggleScreenShare = () => {
    setIsScreenSharing(!isScreenSharing)
  }

  // Handle toggling hand raise
  const handleToggleHandRaise = () => {
    setIsHandRaised(!isHandRaised)
  }

  // Handle leaving the class
  const handleLeaveClass = () => {
    router.push("/dashboard")
  }

  // Format timestamp
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  // Handle selecting a participant for private message
  const handleSelectParticipant = (participantId: string) => {
    if (selectedParticipant === participantId) {
      setSelectedParticipant(null)
      setIsPrivateMessage(false)
    } else {
      const participant = participants.find((p) => p.id === participantId)
      if (participant) {
        setSelectedParticipant(participantId)
        setIsPrivateMessage(true)
      }
    }
  }

  if (loading) {
    return (
      <div className={styles.container}>
        <div className={styles.loading}>Loading class data...</div>
      </div>
    )
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div className={styles.classInfo}>
          <h1>{classInfo.title}</h1>
          <p>
            {classInfo.bootcamp} - Week {classInfo.week} • Instructor: {classInfo.instructor}
          </p>
        </div>
        <div className={styles.headerActions}>
          <button onClick={handleLeaveClass} className={styles.leaveButton}>
            Leave
          </button>
        </div>
      </div>

      <div className={styles.content}>
        <div className={styles.mainContent}>
          <div className={styles.videoGrid}>
            <div className={styles.mainVideo}>
              {isScreenSharing ? (
                <div className={styles.screenShare}>
                  <div className={styles.screenShareContent}>
                    <img src="/placeholder.svg?height=720&width=1280" alt="Screen share" />
                  </div>
                  <div className={styles.screenShareInfo}>
                    <span>{user.name} is sharing their screen</span>
                  </div>
                </div>
              ) : (
                <div className={styles.instructorVideo}>
                  {isVideoOn ? (
                    <img src="/placeholder.svg?height=720&width=1280" alt="Instructor video" />
                  ) : (
                    <div className={styles.videoOff}>
                      <div className={styles.videoOffInitials}>
                        {user.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </div>
                      <div className={styles.videoOffName}>{user.name}</div>
                    </div>
                  )}
                  <div className={styles.videoControls}>
                    <button
                      onClick={handleToggleMute}
                      className={`${styles.controlButton} ${isMuted ? styles.controlActive : ""}`}
                    >
                      {isMuted ? "Unmute" : "Mute"}
                    </button>
                    <button
                      onClick={handleToggleVideo}
                      className={`${styles.controlButton} ${!isVideoOn ? styles.controlActive : ""}`}
                    >
                      {isVideoOn ? "Turn Off Video" : "Turn On Video"}
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className={styles.participantVideos}>
              {participants.slice(0, 4).map((participant) => (
                <div key={participant.id} className={styles.participantVideo}>
                  {participant.isVideoOn ? (
                    <img src="/placeholder.svg?height=180&width=320" alt={`${participant.name}'s video`} />
                  ) : (
                    <div className={styles.videoOff}>
                      <div className={styles.videoOffInitials}>
                        {participant.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </div>
                    </div>
                  )}
                  <div className={styles.participantInfo}>
                    <span>{participant.name}</span>
                    {participant.isMuted && <span className={styles.mutedIcon}>🔇</span>}
                    {participant.isHandRaised && <span className={styles.handRaisedIcon}>✋</span>}
                  </div>
                </div>
              ))}
              {participants.length > 4 && (
                <div className={styles.moreParticipants}>+{participants.length - 4} more</div>
              )}
            </div>
          </div>

          <div className={styles.controls}>
            <div className={styles.controlsLeft}>
              <button
                onClick={handleToggleMute}
                className={`${styles.controlButton} ${isMuted ? styles.controlActive : ""}`}
              >
                {isMuted ? "Unmute" : "Mute"}
              </button>
              <button
                onClick={handleToggleVideo}
                className={`${styles.controlButton} ${!isVideoOn ? styles.controlActive : ""}`}
              >
                {isVideoOn ? "Video Off" : "Video On"}
              </button>
            </div>
            <div className={styles.controlsCenter}>
              <button
                onClick={handleToggleScreenShare}
                className={`${styles.controlButton} ${isScreenSharing ? styles.controlActive : ""}`}
              >
                {isScreenSharing ? "Stop Sharing" : "Share Screen"}
              </button>
              <button
                onClick={handleToggleHandRaise}
                className={`${styles.controlButton} ${isHandRaised ? styles.controlActive : ""}`}
              >
                {isHandRaised ? "Lower Hand" : "Raise Hand"}
              </button>
            </div>
            <div className={styles.controlsRight}>
              <button
                onClick={() => setIsChatOpen(!isChatOpen)}
                className={`${styles.controlButton} ${isChatOpen ? styles.controlActive : ""}`}
              >
                Chat
              </button>
              <button
                onClick={() => setIsParticipantsOpen(!isParticipantsOpen)}
                className={`${styles.controlButton} ${isParticipantsOpen ? styles.controlActive : ""}`}
              >
                Participants
              </button>
            </div>
          </div>
        </div>

        <div className={`${styles.sidebar} ${isChatOpen || isParticipantsOpen ? styles.sidebarOpen : ""}`}>
          <div className={styles.sidebarTabs}>
            <button
              className={`${styles.sidebarTab} ${isChatOpen ? styles.activeTab : ""}`}
              onClick={() => {
                setIsChatOpen(true)
                setIsParticipantsOpen(false)
              }}
            >
              Chat
            </button>
            <button
              className={`${styles.sidebarTab} ${isParticipantsOpen ? styles.activeTab : ""}`}
              onClick={() => {
                setIsParticipantsOpen(true)
                setIsChatOpen(false)
              }}
            >
              Participants ({participants.length})
            </button>
            <button
              className={styles.closeSidebar}
              onClick={() => {
                setIsChatOpen(false)
                setIsParticipantsOpen(false)
              }}
            >
              ✕
            </button>
          </div>

          {isChatOpen && (
            <div className={styles.chatContainer}>
              <div className={styles.chatMessages} ref={chatContainerRef}>
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`${styles.message} ${message.sender === user.name ? styles.ownMessage : ""} ${
                      message.isPrivate ? styles.privateMessage : ""
                    }`}
                  >
                    <div className={styles.messageHeader}>
                      <span className={styles.messageSender}>{message.sender}</span>
                      <span className={styles.messageTime}>{formatTime(message.timestamp)}</span>
                    </div>
                    <div className={styles.messageContent}>
                      {message.isPrivate && <span className={styles.privateLabel}>Private</span>}
                      {message.text}
                    </div>
                  </div>
                ))}
              </div>
              <form onSubmit={handleSendMessage} className={styles.chatForm}>
                {isPrivateMessage && selectedParticipant && (
                  <div className={styles.privateMessageIndicator}>
                    Private message to {participants.find((p) => p.id === selectedParticipant)?.name}
                    <button
                      type="button"
                      onClick={() => {
                        setIsPrivateMessage(false)
                        setSelectedParticipant(null)
                      }}
                      className={styles.cancelPrivateButton}
                    >
                      ✕
                    </button>
                  </div>
                )}
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder={
                    isPrivateMessage
                      ? `Message ${participants.find((p) => p.id === selectedParticipant)?.name} privately...`
                      : "Type a message..."
                  }
                  className={styles.chatInput}
                />
                <button type="submit" className={styles.sendButton}>
                  Send
                </button>
              </form>
            </div>
          )}

          {isParticipantsOpen && (
            <div className={styles.participantsContainer}>
              <div className={styles.participantsList}>
                {participants.map((participant) => (
                  <div key={participant.id} className={styles.participantItem}>
                    <div className={styles.participantDetails}>
                      <div className={styles.participantName}>
                        {participant.name}
                        {participant.role === "instructor" && (
                          <span className={styles.instructorBadge}>Instructor</span>
                        )}
                      </div>
                      <div className={styles.participantStatus}>
                        {participant.isMuted && <span className={styles.statusIcon}>🔇</span>}
                        {!participant.isVideoOn && <span className={styles.statusIcon}>🎦</span>}
                        {participant.isHandRaised && <span className={styles.statusIcon}>✋</span>}
                        {participant.isScreenSharing && <span className={styles.statusIcon}>📊</span>}
                      </div>
                    </div>
                    <div className={styles.participantActions}>
                      <button
                        onClick={() => handleSelectParticipant(participant.id)}
                        className={`${styles.messageButton} ${
                          selectedParticipant === participant.id ? styles.activeButton : ""
                        }`}
                      >
                        Message
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
