'use client';
import { notFound } from 'next/navigation';
import WeekContent from '@/components/bootcamp/week/week-content';
import styles from './week.module.css';
import { useEffect, useState } from 'react';
import CustomFetch from '@/lib/CustormFetch';

// Mock data for bootcamp weeks
const bootcampWeeks = {
  reactnative: {
    title: 'React Native Mobile Development Bootcamp',
    weeks: [
      {
        weekNumber: 1,
        title: 'React Native Fundamentals',
        description:
          'This week covers the fundamentals of React Native development, including setting up your environment, understanding components, styling, and basic navigation.',
        videos: [
          {
            id: 1,
            title: 'Introduction to React Native',
            description:
              'An overview of React Native and its benefits for mobile development.',
            duration: '45:20',
            url: 'https://example.com/video1',
          },
          {
            id: 2,
            title: 'Setting Up Your Development Environment',
            description:
              'Step-by-step guide to setting up React Native, Expo, and required tools.',
            duration: '32:15',
            url: 'https://example.com/video2',
          },
          {
            id: 3,
            title: 'React Native Components',
            description:
              'Understanding the core components in React Native and how to use them.',
            duration: '58:40',
            url: 'https://example.com/video3',
          },
        ],
        resources: [
          {
            id: 1,
            title: 'React Native Documentation',
            type: 'documentation',
            url: 'https://reactnative.dev/docs/getting-started',
          },
          {
            id: 2,
            title: 'Environment Setup Guide',
            type: 'pdf',
            url: 'https://example.com/setup-guide.pdf',
          },
          {
            id: 3,
            title: 'Component Cheatsheet',
            type: 'pdf',
            url: 'https://example.com/component-cheatsheet.pdf',
          },
          {
            id: 4,
            title: 'Week 1 Code Examples',
            type: 'github',
            url: 'https://github.com/example/react-native-week1',
          },
        ],
        liveClass: {
          date: 'June 15, 2023',
          time: '6:00 PM - 8:00 PM EST',
          instructor: 'Alex Rodriguez',
          topic: 'Building Your First React Native App',
          link: 'https://zoom.us/j/123456789',
          description:
            "In this live session, we'll build a complete React Native app from scratch, covering components, styling, and navigation.",
        },
        quizzes: [
          {
            id: 1,
            title: 'React Native Basics Quiz',
            questions: 10,
            timeLimit: '20 minutes',
            url: 'https://example.com/quiz1',
          },
          {
            id: 2,
            title: 'Components and Props Quiz',
            questions: 15,
            timeLimit: '30 minutes',
            url: 'https://example.com/quiz2',
          },
        ],
        completed: false,
      },
      {
        weekNumber: 2,
        title: 'Expo Ecosystem',
        description:
          'Learn about the Expo ecosystem, including Expo CLI, Expo SDK features, libraries, and development builds.',
        videos: [
          {
            id: 1,
            title: 'Introduction to Expo',
            description:
              'An overview of Expo and how it simplifies React Native development.',
            duration: '38:45',
            url: 'https://example.com/video1',
          },
          {
            id: 2,
            title: 'Expo SDK Features',
            description:
              'Exploring the powerful features provided by the Expo SDK.',
            duration: '52:10',
            url: 'https://example.com/video2',
          },
          {
            id: 3,
            title: 'Expo Development Builds',
            description: 'How to create and use development builds with Expo.',
            duration: '41:30',
            url: 'https://example.com/video3',
          },
        ],
        resources: [
          {
            id: 1,
            title: 'Expo Documentation',
            type: 'documentation',
            url: 'https://docs.expo.dev/',
          },
          {
            id: 2,
            title: 'Expo SDK API Reference',
            type: 'documentation',
            url: 'https://docs.expo.dev/versions/latest/',
          },
          {
            id: 3,
            title: 'Week 2 Code Examples',
            type: 'github',
            url: 'https://github.com/example/react-native-week2',
          },
        ],
        liveClass: {
          date: 'June 22, 2023',
          time: '6:00 PM - 8:00 PM EST',
          instructor: 'Sarah Chen',
          topic: 'Leveraging Expo for Rapid Development',
          link: 'https://zoom.us/j/123456789',
          description:
            "In this live session, we'll explore how to use Expo to accelerate your React Native development process.",
        },
        quizzes: [
          {
            id: 1,
            title: 'Expo Fundamentals Quiz',
            questions: 12,
            timeLimit: '25 minutes',
            url: 'https://example.com/quiz1',
          },
        ],
        completed: false,
      },
      // Additional weeks would be defined here
    ],
  },
  javascript: {
    title: 'JavaScript Mastery Bootcamp',
    weeks: [
      {
        weekNumber: 1,
        title: 'JavaScript Fundamentals',
        description:
          'This week covers the fundamentals of JavaScript, including variables, data types, functions, scope, control flow, arrays, and objects.',
        videos: [
          {
            id: 1,
            title: 'Introduction to JavaScript',
            description:
              'An overview of JavaScript and its role in web development.',
            duration: '42:15',
            url: 'https://example.com/video1',
          },
          {
            id: 2,
            title: 'Variables and Data Types',
            description:
              'Understanding JavaScript variables, primitive types, and objects.',
            duration: '38:50',
            url: 'https://example.com/video2',
          },
          {
            id: 3,
            title: 'Functions and Scope',
            description:
              'How to define and use functions, and understanding variable scope.',
            duration: '55:20',
            url: 'https://example.com/video3',
          },
        ],
        resources: [
          {
            id: 1,
            title: 'MDN JavaScript Guide',
            type: 'documentation',
            url: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide',
          },
          {
            id: 2,
            title: 'JavaScript Fundamentals Cheatsheet',
            type: 'pdf',
            url: 'https://example.com/js-cheatsheet.pdf',
          },
          {
            id: 3,
            title: 'Week 1 Code Examples',
            type: 'github',
            url: 'https://github.com/example/javascript-week1',
          },
        ],
        liveClass: {
          date: 'June 15, 2023',
          time: '9:00 AM - 11:00 AM EST',
          instructor: 'John Smith',
          topic: 'JavaScript Fundamentals in Practice',
          link: 'https://zoom.us/j/123456789',
          description:
            "In this live session, we'll work through practical examples of JavaScript fundamentals and solve coding challenges together.",
        },
        quizzes: [
          {
            id: 1,
            title: 'JavaScript Basics Quiz',
            questions: 15,
            timeLimit: '30 minutes',
            url: 'https://example.com/quiz1',
          },
          {
            id: 2,
            title: 'Functions and Scope Quiz',
            questions: 10,
            timeLimit: '20 minutes',
            url: 'https://example.com/quiz2',
          },
        ],
        completed: false,
      },
      // Additional weeks would be defined here
    ],
  },
  // Additional bootcamps would be defined here
};

export default function WeekPage({
  params,
}: {
  params: { slug: string; weekNumber: string };
}) {
  const { slug, weekNumber } = params;
  const [bootcamp, setBootcamp] = useState<any>(null);
  console.log(slug, weekNumber);

  useEffect(() => {
    const loadBootcamp = async () => {
      try {
        const { data } = await CustomFetch.get(`/bootcamps/${slug}`);
        console.log(591, data);
      } catch (error) {
        console.error('Failed to fetch bootcamp:', error);
        notFound(); // fallback if invalid slug
      }
    };

    loadBootcamp();
  }, [slug]);

  if (!bootcamp) {
    notFound();
  }

  const weekData = bootcamp.weeks.find(
    (week: any) => week.weekNumber === Number.parseInt(weekNumber)
  );

  if (!weekData) {
    notFound();
  }

  return (
    <div className={styles.container}>
      <WeekContent
        bootcampSlug={slug}
        bootcampTitle={bootcamp.title}
        weekData={weekData}
        totalWeeks={bootcamp.weeks.length}
      />
    </div>
  );
}
