'use client';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import styles from './page.module.css';
import { useEffect, useState } from 'react';
import { useBootcampStore } from '@/store/bootcamp-store';
import CustomFetch from '@/lib/CustormFetch';

// Mock data for bootcamps
const bootcamps = {
  javascript: {
    title: 'JavaScript Mastery Bootcamp',
    subtitle: 'Master modern JavaScript from fundamentals to advanced concepts',
    description:
      "Our JavaScript Mastery Bootcamp is an intensive 8-week program designed to take you from the basics to advanced JavaScript concepts. You'll learn modern ES6+ syntax, asynchronous programming, DOM manipulation, and how to build full-stack applications with JavaScript.",
    duration: '8 weeks',
    schedule: 'Monday to Friday, 9:00 AM - 1:00 PM',
    startDate: 'June 15, 2023',
    price: '$1,999',
    level: 'Beginner to Intermediate',
    prerequisites: [
      'Basic HTML and CSS knowledge',
      'No prior JavaScript experience required',
    ],
    image: '/placeholder.svg?height=500&width=800',
    instructors: [
      {
        name: 'John Smith',
        role: 'Lead Instructor',
        bio: '10+ years of JavaScript development experience. Former senior developer at Google.',
        avatar: '/placeholder.svg?height=100&width=100',
      },
      {
        name: 'Emily Johnson',
        role: 'Teaching Assistant',
        bio: 'Full-stack developer with 5 years of experience. JavaScript enthusiast and open source contributor.',
        avatar: '/placeholder.svg?height=100&width=100',
      },
    ],
    curriculum: [
      {
        week: 1,
        title: 'JavaScript Fundamentals',
        topics: [
          'Variables and Data Types',
          'Functions and Scope',
          'Control Flow',
          'Arrays and Objects',
        ],
      },
      {
        week: 2,
        title: 'Advanced JavaScript Concepts',
        topics: [
          'ES6+ Features',
          'Destructuring',
          'Arrow Functions',
          'Spread and Rest Operators',
        ],
      },
      {
        week: 3,
        title: 'Asynchronous JavaScript',
        topics: ['Callbacks', 'Promises', 'Async/Await', 'Fetch API'],
      },
      {
        week: 4,
        title: 'DOM Manipulation',
        topics: [
          'Selecting Elements',
          'Event Handling',
          'Creating and Modifying Elements',
          'Browser Storage',
        ],
      },
      {
        week: 5,
        title: 'Introduction to Frontend Frameworks',
        topics: [
          'Modern JavaScript Ecosystem',
          'NPM and Build Tools',
          'Introduction to React',
          'Component Basics',
        ],
      },
      {
        week: 6,
        title: 'Backend JavaScript with Node.js',
        topics: [
          'Node.js Basics',
          'Express Framework',
          'RESTful APIs',
          'MongoDB Integration',
        ],
      },
      {
        week: 7,
        title: 'Full-Stack Project',
        topics: [
          'Project Planning',
          'Frontend Implementation',
          'Backend Implementation',
          'Database Integration',
        ],
      },
      {
        week: 8,
        title: 'Project Completion and Career Prep',
        topics: [
          'Project Deployment',
          'Code Reviews',
          'Portfolio Building',
          'Interview Preparation',
        ],
      },
    ],
    faqs: [
      {
        question: 'Do I need prior programming experience?',
        answer:
          "No prior JavaScript experience is required, but basic HTML and CSS knowledge is recommended. We'll start from the fundamentals and progress to advanced topics.",
      },
      {
        question: 'What will I be able to build after this bootcamp?',
        answer:
          "By the end of the bootcamp, you'll be able to build full-stack JavaScript applications, including interactive websites, single-page applications with React, and backend APIs with Node.js.",
      },
      {
        question: 'Is there a job guarantee?',
        answer:
          "While we don't offer a job guarantee, our career services team will work with you on resume building, interview preparation, and connecting with our hiring partners.",
      },
      {
        question: 'What happens if I miss a class?',
        answer:
          'All sessions are recorded and available for review. We also offer 1-on-1 office hours to help you catch up on missed material.',
      },
    ],
  },
  reactnative: {
    title: 'React Native Mobile Development Bootcamp',
    subtitle:
      'Build cross-platform mobile apps with React Native, Expo, and Zustand',
    description:
      "Our React Native Mobile Development Bootcamp is an intensive 10-week program designed to teach you how to build professional, cross-platform mobile applications. You'll learn React Native fundamentals, Expo tooling, state management with Zustand, and how to deploy your apps to the App Store and Google Play.",
    duration: '10 weeks',
    schedule: 'Monday to Friday, 6:00 PM - 9:00 PM',
    startDate: 'July 1, 2023',
    price: '$2,499',
    level: 'Intermediate',
    prerequisites: [
      'JavaScript fundamentals',
      'Basic React knowledge',
      'Understanding of ES6+ syntax',
    ],
    image: '/placeholder.svg?height=500&width=800',
    instructors: [
      {
        name: 'Alex Rodriguez',
        role: 'Lead Instructor',
        bio: 'Mobile app developer with 8+ years of experience. Built over 20 production React Native apps.',
        avatar: '/placeholder.svg?height=100&width=100',
      },
      {
        name: 'Sarah Chen',
        role: 'Teaching Assistant',
        bio: 'React Native specialist with experience at multiple startups. Open source contributor to Expo.',
        avatar: '/placeholder.svg?height=100&width=100',
      },
    ],
    curriculum: [
      {
        week: 1,
        title: 'React Native Fundamentals',
        topics: [
          'Setting Up Your Environment',
          'React Native Components',
          'Styling in React Native',
          'Navigation Basics',
        ],
      },
      {
        week: 2,
        title: 'Expo Ecosystem',
        topics: [
          'Expo CLI and Workflow',
          'Expo SDK Features',
          'Using Expo Libraries',
          'Expo Development Builds',
        ],
      },
      {
        week: 3,
        title: 'Advanced UI Components',
        topics: [
          'Custom Components',
          'Animations',
          'Gesture Handling',
          'Responsive Design',
        ],
      },
      {
        week: 4,
        title: 'Navigation and Routing',
        topics: [
          'Expo Router',
          'Stack Navigation',
          'Tab Navigation',
          'Drawer Navigation',
        ],
      },
      {
        week: 5,
        title: 'State Management with Zustand',
        topics: [
          'Zustand Fundamentals',
          'Creating Stores',
          'Async Actions',
          'Persisting State',
        ],
      },
      {
        week: 6,
        title: 'Working with APIs',
        topics: [
          'Fetching Data',
          'Authentication',
          'Error Handling',
          'Offline Support',
        ],
      },
      {
        week: 7,
        title: 'Native Device Features',
        topics: [
          'Camera Access',
          'Location Services',
          'Push Notifications',
          'Local Storage',
        ],
      },
      {
        week: 8,
        title: 'Testing and Debugging',
        topics: [
          'Debugging Tools',
          'Unit Testing',
          'Integration Testing',
          'Performance Optimization',
        ],
      },
      {
        week: 9,
        title: 'Capstone Project Development',
        topics: [
          'Project Planning',
          'UI/UX Implementation',
          'Feature Development',
          'Testing',
        ],
      },
      {
        week: 10,
        title: 'Deployment and Publishing',
        topics: [
          'Building for Production',
          'App Store Submission',
          'Google Play Submission',
          'CI/CD Setup',
        ],
      },
    ],
    faqs: [
      {
        question: 'Do I need to own a Mac for iOS development?',
        answer:
          'While a Mac is required for publishing to the App Store, you can develop and test iOS apps using Expo on any computer. We provide cloud build services for students without Macs.',
      },
      {
        question: 'Will this bootcamp cover both iOS and Android development?',
        answer:
          "Yes! React Native allows you to build for both platforms simultaneously. We'll cover platform-specific considerations and how to handle differences between iOS and Android.",
      },
      {
        question: 'Do I need to know React before taking this bootcamp?',
        answer:
          "Basic React knowledge is recommended. If you're new to React, we offer a pre-bootcamp workshop to get you up to speed with the fundamentals.",
      },
      {
        question: 'What kind of projects will I build?',
        answer:
          "You'll build several projects throughout the bootcamp, including a social media app, a location-based service, and a final capstone project of your choice that you can showcase in your portfolio.",
      },
    ],
  },
  react: {
    title: 'React Frontend Development Bootcamp',
    subtitle: 'Learn to build modern, responsive web applications with React',
    description:
      "Our React Frontend Development Bootcamp is an intensive 8-week program designed to teach you how to build modern, responsive web applications with React and related technologies. You'll learn React fundamentals, state management, routing, and how to build and deploy production-ready applications.",
    duration: '8 weeks',
    schedule: 'Monday, Wednesday, Friday, 6:00 PM - 9:00 PM',
    startDate: 'June 20, 2023',
    price: '$1,899',
    level: 'Intermediate',
    prerequisites: [
      'JavaScript fundamentals',
      'HTML and CSS knowledge',
      'Understanding of ES6+ syntax',
    ],
    image: '/placeholder.svg?height=500&width=800',
    instructors: [
      {
        name: 'David Kim',
        role: 'Lead Instructor',
        bio: 'Frontend architect with 10+ years of experience. React specialist and conference speaker.',
        avatar: '/placeholder.svg?height=100&width=100',
      },
      {
        name: 'Lisa Wong',
        role: 'Teaching Assistant',
        bio: 'UI/UX designer and React developer. Previously worked at Facebook on React-based projects.',
        avatar: '/placeholder.svg?height=100&width=100',
      },
    ],
    curriculum: [
      {
        week: 1,
        title: 'React Fundamentals',
        topics: [
          'React Components',
          'JSX Syntax',
          'Props and State',
          'Event Handling',
        ],
      },
      {
        week: 2,
        title: 'React Hooks',
        topics: ['useState', 'useEffect', 'useContext', 'Custom Hooks'],
      },
      {
        week: 3,
        title: 'Routing and Navigation',
        topics: [
          'React Router',
          'Dynamic Routes',
          'Protected Routes',
          'Navigation Guards',
        ],
      },
      {
        week: 4,
        title: 'State Management',
        topics: [
          'Context API',
          'Zustand',
          'Redux (Overview)',
          'State Management Patterns',
        ],
      },
      {
        week: 5,
        title: 'Working with APIs',
        topics: [
          'Fetch and Axios',
          'React Query',
          'Error Handling',
          'Loading States',
        ],
      },
      {
        week: 6,
        title: 'Styling and UI Libraries',
        topics: [
          'CSS-in-JS',
          'Styled Components',
          'Tailwind CSS',
          'Component Libraries',
        ],
      },
      {
        week: 7,
        title: 'Testing and Performance',
        topics: [
          'Unit Testing with Jest',
          'Component Testing with React Testing Library',
          'Performance Optimization',
          'Code Splitting',
        ],
      },
      {
        week: 8,
        title: 'Deployment and Advanced Topics',
        topics: [
          'Building for Production',
          'Deployment Options',
          'CI/CD Integration',
          'Server-Side Rendering',
        ],
      },
    ],
    faqs: [
      {
        question: 'Is this bootcamp suitable for beginners?',
        answer:
          "This bootcamp is designed for those with some JavaScript knowledge. If you're a complete beginner, we recommend taking our JavaScript Fundamentals course first.",
      },
      {
        question: 'What will I be able to build after this bootcamp?',
        answer:
          "By the end of the bootcamp, you'll be able to build complex, interactive web applications with React, implement state management, connect to APIs, and deploy your applications to production.",
      },
      {
        question: 'Do you provide job placement assistance?',
        answer:
          'Yes, we offer resume reviews, portfolio feedback, mock interviews, and connections to our hiring partners for all bootcamp graduates.',
      },
      {
        question: 'Is there homework or projects outside of class time?',
        answer:
          "Yes, you should expect to spend 10-15 hours per week outside of class working on assignments and projects to reinforce what you've learned.",
      },
    ],
  },
  nodejs: {
    title: 'Node.js Backend Development Bootcamp',
    subtitle:
      'Master server-side JavaScript with Node.js, Express, and MongoDB',
    description:
      "Our Node.js Backend Development Bootcamp is an intensive 9-week program designed to teach you how to build scalable, secure backend services with Node.js. You'll learn server-side JavaScript, RESTful API development, database integration, authentication, and deployment strategies.",
    duration: '9 weeks',
    schedule:
      'Tuesday and Thursday, 6:00 PM - 9:00 PM, Saturday 10:00 AM - 2:00 PM',
    startDate: 'July 10, 2023',
    price: '$2,199',
    level: 'Intermediate to Advanced',
    prerequisites: [
      'JavaScript fundamentals',
      'Understanding of ES6+ syntax',
      'Basic knowledge of HTTP and APIs',
    ],
    image: '/placeholder.svg?height=500&width=800',
    instructors: [
      {
        name: 'Michael Johnson',
        role: 'Lead Instructor',
        bio: 'Backend architect with 12+ years of experience. Node.js expert and author of several programming books.',
        avatar: '/placeholder.svg?height=100&width=100',
      },
      {
        name: 'Priya Patel',
        role: 'Teaching Assistant',
        bio: 'Full-stack developer specializing in Node.js microservices. Previously at AWS.',
        avatar: '/placeholder.svg?height=100&width=100',
      },
    ],
    curriculum: [
      {
        week: 1,
        title: 'Node.js Fundamentals',
        topics: [
          'Node.js Architecture',
          'NPM Ecosystem',
          'Modules System',
          'Asynchronous Programming',
        ],
      },
      {
        week: 2,
        title: 'Express Framework',
        topics: [
          'Setting Up Express',
          'Routing',
          'Middleware',
          'Error Handling',
        ],
      },
      {
        week: 3,
        title: 'RESTful API Development',
        topics: [
          'API Design Principles',
          'CRUD Operations',
          'Validation',
          'Documentation',
        ],
      },
      {
        week: 4,
        title: 'Database Integration',
        topics: [
          'MongoDB Basics',
          'Mongoose ODM',
          'Data Modeling',
          'Queries and Aggregation',
        ],
      },
      {
        week: 5,
        title: 'Authentication and Authorization',
        topics: [
          'JWT Authentication',
          'OAuth Integration',
          'Role-Based Access Control',
          'Security Best Practices',
        ],
      },
      {
        week: 6,
        title: 'Testing and Debugging',
        topics: [
          'Unit Testing',
          'Integration Testing',
          'Debugging Techniques',
          'Test Coverage',
        ],
      },
      {
        week: 7,
        title: 'Performance and Scaling',
        topics: [
          'Performance Optimization',
          'Caching Strategies',
          'Load Balancing',
          'Horizontal Scaling',
        ],
      },
      {
        week: 8,
        title: 'Deployment and DevOps',
        topics: [
          'Deployment Options',
          'Docker Containerization',
          'CI/CD Pipelines',
          'Monitoring and Logging',
        ],
      },
      {
        week: 9,
        title: 'Capstone Project',
        topics: ['Project Planning', 'Implementation', 'Testing', 'Deployment'],
      },
    ],
    faqs: [
      {
        question: 'Do I need frontend experience for this bootcamp?',
        answer:
          "While frontend experience is helpful, it's not required. This bootcamp focuses on backend development with Node.js, and we'll provide any necessary frontend code for testing your APIs.",
      },
      {
        question: 'Will I learn about databases other than MongoDB?',
        answer:
          "The primary focus is on MongoDB, but we'll also cover SQL databases and provide resources for learning other database systems. The principles you learn will be applicable across different database technologies.",
      },
      {
        question:
          'Is this bootcamp suitable for experienced developers from other languages?',
        answer:
          "Yes, if you're coming from another programming language like Python, Java, or Ruby, you'll find this bootcamp helpful for transitioning to Node.js development. We'll help you leverage your existing knowledge.",
      },
      {
        question: 'What kind of projects will I build?',
        answer:
          "You'll build several backend services, including a RESTful API, an authentication system, and a final capstone project that could be an e-commerce backend, social media API, or another complex system of your choice.",
      },
    ],
  },
};

export default function BootcampSalesPage({
  params,
}: {
  params: { slug: string };
}) {
  const { slug } = params;
  console.log(578, slug);
  // const bootcamp = bootcamps[slug as keyof typeof bootcamps];
  const bootcampMap = useBootcampStore((state) => state.bootcampMap);
  const setBootcamp = useBootcampStore((state) => state.setBootcamp);
  const [bootcamp, setLocalBootcamp] = useState<any>(null);

  useEffect(() => {
    const loadBootcamp = async () => {
      const cached = bootcampMap.find((b: any) => b._id === slug);
      if (cached) return setLocalBootcamp(cached);

      try {
        const { data } = await CustomFetch.get(`/bootcamps/${slug}`);
        console.log(591, data);
        setBootcamp(data); // save to Zustand
        setLocalBootcamp(data);
      } catch (error) {
        console.error('Failed to fetch bootcamp:', error);
        notFound(); // fallback if invalid slug
      }
    };

    loadBootcamp();
  }, [slug]);

  if (!bootcamp) return <p>Loading...</p>;

  if (!bootcamp) {
    notFound();
  }

  return (
    <div className={styles.container}>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>{bootcamp.title}</h1>
          <p className={styles.subtitle}>{bootcamp.subtitle}</p>
          <div className={styles.heroCta}>
            <Link
              href={`/bootcamp/${slug}/week/1`}
              className={styles.ctaButton}
            >
              Start Learning
            </Link>
            <Link href="/bootcamp/register" className={styles.secondaryButton}>
              Apply Now
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.overview}>
        <div className={styles.overviewGrid}>
          <div className={styles.overviewContent}>
            <h2>About This Bootcamp</h2>
            <p>{bootcamp.description}</p>

            <div className={styles.keyDetails}>
              <div className={styles.detailItem}>
                <div className={styles.detailIcon}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <circle cx="12" cy="12" r="10"></circle>
                    <polyline points="12 6 12 12 16 14"></polyline>
                  </svg>
                </div>
                <div className={styles.detailContent}>
                  <h3>Duration</h3>
                  <p>{bootcamp.duration}</p>
                </div>
              </div>

              <div className={styles.detailItem}>
                <div className={styles.detailIcon}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect
                      x="3"
                      y="4"
                      width="18"
                      height="18"
                      rx="2"
                      ry="2"
                    ></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                  </svg>
                </div>
                <div className={styles.detailContent}>
                  <h3>Start Date</h3>
                  <p>{bootcamp.startDate}</p>
                </div>
              </div>

              <div className={styles.detailItem}>
                <div className={styles.detailIcon}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
                    <path d="M2 17l10 5 10-5"></path>
                    <path d="M2 12l10 5 10-5"></path>
                  </svg>
                </div>
                <div className={styles.detailContent}>
                  <h3>Skill Level</h3>
                  <p>{bootcamp.level}</p>
                </div>
              </div>

              <div className={styles.detailItem}>
                <div className={styles.detailIcon}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <line x1="12" y1="1" x2="12" y2="23"></line>
                    <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                  </svg>
                </div>
                <div className={styles.detailContent}>
                  <h3>Price</h3>
                  <p>{bootcamp.price}</p>
                </div>
              </div>
            </div>

            <div className={styles.prerequisites}>
              <h3>Prerequisites</h3>
              <ul>
                {bootcamp.prerequisites.map(
                  (prerequisite: string, index: number) => (
                    <li key={index}>{prerequisite}</li>
                  )
                )}
              </ul>
            </div>
          </div>

          <div className={styles.overviewImage}>
            <Image
              src={bootcamp.image || '/placeholder.svg'}
              alt={bootcamp.title}
              width={800}
              height={500}
              className={styles.image}
            />
          </div>
        </div>
      </section>

      <section className={styles.curriculum}>
        <div className={styles.sectionHeader}>
          <h2>What You'll Learn</h2>
          <p>Week-by-week curriculum breakdown</p>
        </div>

        <div className={styles.curriculumGrid}>
          {bootcamp.curriculum.slice(0, 4).map((week: any) => (
            <div key={week.week} className={styles.curriculumCard}>
              <div className={styles.weekBadge}>Week {week.week}</div>
              <h3>{week.title}</h3>
              <ul>
                {week.topics.map((topic: string, index: number) => (
                  <li key={index}>{topic}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className={styles.curriculumCta}>
          <Link
            href={`/bootcamp/${slug}/week/1`}
            className={styles.secondaryButton}
          >
            Start Learning
          </Link>
        </div>
      </section>

      <section className={styles.instructors}>
        <div className={styles.sectionHeader}>
          <h2>Meet Your Instructors</h2>
          <p>Learn from industry experts with real-world experience</p>
        </div>

        <div className={styles.instructorsGrid}>
          {bootcamp.instructors.map((instructor: any, index: any) => (
            <div key={index} className={styles.instructorCard}>
              <div className={styles.instructorAvatar}>
                <Image
                  src={instructor.avatar || '/placeholder.svg'}
                  alt={instructor.name}
                  width={100}
                  height={100}
                  className={styles.avatar}
                />
              </div>
              <h3>{instructor.name}</h3>
              <p className={styles.instructorRole}>{instructor.role}</p>
              <p className={styles.instructorBio}>{instructor.bio}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.faq}>
        <div className={styles.sectionHeader}>
          <h2>Frequently Asked Questions</h2>
          <p>Get answers to common questions about this bootcamp</p>
        </div>

        <div className={styles.faqList}>
          {bootcamp.faqs.map((faq: any, index: number) => (
            <div key={index} className={styles.faqItem}>
              <h3>{faq.question}</h3>
              <p>{faq.answer}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Ready to Transform Your Career?</h2>
          <p>
            Join our {bootcamp.title} and gain the skills employers are looking
            for. Limited spots available!
          </p>
          <div className={styles.ctaButtons}>
            <Link href="/bootcamp/register" className={styles.ctaButton}>
              Apply Now
            </Link>
            <Link
              href={`/bootcamp/${slug}/week/1`}
              className={styles.secondaryButton}
            >
              Preview Week 1
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
