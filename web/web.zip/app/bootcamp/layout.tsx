import type React from 'react';
import type { Metadata } from 'next';
import BootcampHeader from '@/components/bootcamp/layout/header';
import BootcampFooter from '@/components/bootcamp/layout/footer';
import styles from './bootcamp.module.css';

export const metadata: Metadata = {
  title: 'EdTech Bootcamps - Intensive Learning Programs',
  description:
    'Join our intensive bootcamps and master JavaScript, React, React Native, Node.js and more in weeks.',
};

export default function BootcampLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className={styles.bootcampLayout}>
      <BootcampHeader />
      <main className={styles.bootcampMain}>{children}</main>
      <BootcampFooter />
    </div>
  );
}
