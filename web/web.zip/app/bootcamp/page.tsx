'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth-store';
import styles from './bootcamp.module.css';

export default function BootcampPage() {
  const router = useRouter();
  const { user, isAuthenticated } = useAuthStore();

  useEffect(() => {
    // Check authentication and bootcamp access
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('token');
      const userStr = localStorage.getItem('user');

      if (!token || !userStr) {
        // Not authenticated, redirect to login
        router.replace('/login');
        return;
      }

      try {
        const userData = JSON.parse(userStr);
        if (!userData.bootcamp) {
          // Not a bootcamp user, redirect to dashboard
          router.replace('/dashboard');
        }
      } catch (error) {
        console.error('Error parsing user data:', error);
        router.replace('/login');
      }
    }
  }, [router, isAuthenticated]);

  return (
    <div className={styles.bootcampPage}>
      <div className={styles.container}>
        <div className={styles.header}>
          <h1 className={styles.title}>Bootcamp Dashboard</h1>
          <p className={styles.subtitle}>
            Your intensive JavaScript training program
          </p>
        </div>

        {user ? (
          <>
            <div className={styles.welcomeCard}>
              <div className={styles.welcomeContent}>
                <h2>Welcome to the JavaScript Mastery Bootcamp!</h2>
                <p>
                  This 12-week intensive program will take you from beginner to
                  professional JavaScript developer. Follow the curriculum,
                  complete assignments, and participate in live sessions.
                </p>
                <div className={styles.stats}>
                  <div className={styles.stat}>
                    <span className={styles.statValue}>Week 3</span>
                    <span className={styles.statLabel}>Current Week</span>
                  </div>
                  <div className={styles.stat}>
                    <span className={styles.statValue}>8</span>
                    <span className={styles.statLabel}>
                      Assignments Completed
                    </span>
                  </div>
                  <div className={styles.stat}>
                    <span className={styles.statValue}>75%</span>
                    <span className={styles.statLabel}>Attendance</span>
                  </div>
                </div>
              </div>
            </div>

            <div className={styles.nextSession}>
              <h2>Next Live Session</h2>
              <div className={styles.sessionCard}>
                <div className={styles.sessionDate}>
                  <span className={styles.day}>15</span>
                  <span className={styles.month}>June</span>
                </div>
                <div className={styles.sessionInfo}>
                  <h3>Advanced JavaScript Patterns</h3>
                  <p>
                    Learn about factory functions, modules, and design patterns
                  </p>
                  <div className={styles.sessionTime}>
                    <span>3:00 PM - 5:00 PM EST</span>
                    <button
                      className={styles.joinButton}
                      onClick={() => router.push('/live-classes/join/123')}
                    >
                      Join Live
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className={styles.curriculumSection}>
              <h2>Current Module</h2>
              <div className={styles.moduleCard}>
                <h3>Module 3: DOM Manipulation & Browser APIs</h3>
                <div className={styles.progressBar}>
                  <div
                    className={styles.progressFill}
                    style={{ width: '45%' }}
                  ></div>
                  <span>45% Complete</span>
                </div>
                <div className={styles.lessons}>
                  <div className={styles.lesson}>
                    <div className={styles.lessonStatus}>✓</div>
                    <div className={styles.lessonContent}>
                      <h4>DOM Fundamentals</h4>
                      <p>Learn the basics of DOM manipulation</p>
                    </div>
                  </div>
                  <div className={styles.lesson}>
                    <div className={styles.lessonStatus}>✓</div>
                    <div className={styles.lessonContent}>
                      <h4>Events & Event Handling</h4>
                      <p>Understanding browser events</p>
                    </div>
                  </div>
                  <div className={styles.lesson}>
                    <div className={styles.lessonStatusCurrent}>→</div>
                    <div className={styles.lessonContent}>
                      <h4>Fetch API & AJAX</h4>
                      <p>Working with asynchronous requests</p>
                      <button
                        className={styles.continueButton}
                        onClick={() =>
                          router.push('/bootcamp/modules/3/lesson/3')
                        }
                      >
                        Continue
                      </button>
                    </div>
                  </div>
                  <div className={styles.lesson}>
                    <div className={styles.lessonStatusIncomplete}></div>
                    <div className={styles.lessonContent}>
                      <h4>Local Storage & Session Storage</h4>
                      <p>Persisting data in the browser</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="loading-container">
            <div className="loading-spinner"></div>
          </div>
        )}
      </div>
    </div>
  );
}
